﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEL
{
    public class License_Management
    {
        public string Company_Name { get; set; }
        public string Address { get; set; }
        public long Contact_no { get; set; }
        public string Key_contact_name { get; set; }
        public string Licenseperiod { get; set; }
        public string Email { get; set; }
        public DateTime Date_of_License_reg { get; set; }
        public string Commission_type { get; set; }
        public string Login_Id { get; set; }

    }

}
