﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEL
{
    public class Agent_Commission
    {
      
        public DateTime From_Date { get; set; }
        public DateTime To_Date { get; set; }
        public int Login_Id { get; set; }

    }
}
