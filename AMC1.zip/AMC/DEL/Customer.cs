﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEL
{
    public class Customer
    {
        public int Customer_id { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        public DateTime Date_of_birth { get; set; }
        public string Address { get; set; }
        public long Contact_no { get; set; }
        public string Email { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public DateTime Date_of_join { get; set; }
        public long Zipcode { get; set; }
       
    }
}
